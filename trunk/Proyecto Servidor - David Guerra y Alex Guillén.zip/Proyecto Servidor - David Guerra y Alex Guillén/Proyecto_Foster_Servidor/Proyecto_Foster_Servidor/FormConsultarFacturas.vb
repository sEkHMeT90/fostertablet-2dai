﻿Imports FostersClases
''' <summary>
''' Muestra todas las facturas de la base de datos
''' </summary>
''' <author>David Guerra Abad</author>
Public Class FormConsultarFacturas

#Region "Variables"
    Dim _dsFacturas As DataSet
#End Region

#Region "Eventos"
    Private Sub FormConsultarFacturas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        _dsFacturas = Factura.CargarDatos()
        dgvFacturas.DataSource = _dsFacturas.Tables("facturas")
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvFacturas.CellContentClick
        FormGestionarFacturas.codigo = dgvFacturas.CurrentRow.Cells(1).Value
        FormGestionarFacturas.ShowDialog()
    End Sub
#End Region

End Class
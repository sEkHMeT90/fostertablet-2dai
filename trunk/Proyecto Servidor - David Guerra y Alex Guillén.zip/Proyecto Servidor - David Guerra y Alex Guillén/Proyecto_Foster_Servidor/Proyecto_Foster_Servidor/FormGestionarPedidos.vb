﻿Imports FostersClases
''' <summary>
''' Form que muestra las lineas de Pedidos de un pedido
''' </summary>
''' <author>David Guerra Abad</author>
Public Class FormGestionarPedidos

#Region "Variables"
    Dim _codigo As String
    Dim _dsFacturas As DataSet
#End Region

#Region "Propiedades"
    Public Property codigo As String
        Set(ByVal value As String)
            _codigo = value
        End Set
        Get
            Return _codigo
        End Get
    End Property
#End Region

#Region "Eventos"

    Private Sub FormGestionarPedidos_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If _dsFacturas.HasChanges Then
            MsgBox(LineaPedido.Actualizar(_dsFacturas))
        End If
    End Sub
    Private Sub FormGestionarPedidos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim pedido As Pedido = New Pedido()
        pedido.Codigo = _codigo
        _dsFacturas = LineaPedido.Cargar(pedido)
        dgvPedidos.DataSource = _dsFacturas.Tables("lineas_pedido")
    End Sub
#End Region

End Class
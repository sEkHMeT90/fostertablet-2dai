﻿Imports FostersClases
Imports Oracle.DataAccess.Client

''' <summary>
''' 
''' </summary>
''' <author>David Guerra Abad, Alejandro Guillén Esteso</author>
Public Class FormNuevoProducto

#Region "Variables"
    Dim _lector As OracleDataReader
    Dim _codigos As List(Of String)
    Dim _codCategoria As DataRowView
    Dim _codSubCategoria As DataRowView
    Dim _codIva As DataRowView
    Dim _codGuanicion As DataRowView
#End Region

#Region "Eventos"
    Private Sub FormNuevoProducto_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Cargamos el código del nuevo producto
        Dim BD As New BBDD
        BD.Conectar()
        _lector = BD.Consultar("SELECT MAX(codigo) FROM productos")
        If _lector.Read() Then
            If _lector(0) IsNot Nothing Then
                tbCodigo.Text = _lector(0).ToString + 1
            Else
                tbCodigo.Text = 1
            End If
        End If
        BD.Desconectar()

        ' Cargamos Categoria
        cbCategoria.DataSource = Categoria.CargarDatos.Tables("categorias")
        cbCategoria.DisplayMember = "nombre"
        cbCategoria.ValueMember = "codigo"

        ' Cargamos Guarniciones
        clbGuarniciones.DataSource = SubCategoria.CargarDatos(Categoria.Cargar(1)).Tables("subcategorias")
        clbGuarniciones.DisplayMember = "nombre"
        clbGuarniciones.ValueMember = "codigo"

        ' Cargamos los tipos de iva
        cbIVA.DataSource = TipoIVA.CargarDatos.Tables("tipos_iva")
        cbIVA.DisplayMember = "nombre"
        cbIVA.ValueMember = "codigo"

    End Sub


    Private Sub btAniadir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btAniadir.Click
        Dim nuevoProducto As New Producto
        ' Nombre, Descripción y Calorias
        nuevoProducto.Nombre = tbNombre.Text
        nuevoProducto.Descripcion = tbDescripcion.Text
        nuevoProducto.Calorias = tbCalorias.Text

        ' SubCategoria y Categoria
        _codSubCategoria = cbSubcategoria.Items(cbSubcategoria.SelectedIndex)
        nuevoProducto.SubCategoria = SubCategoria.Cargar(_codSubCategoria.Item(0), Categoria.Cargar(_codCategoria.Item(0)))

        'Guarniciones
        Dim cantidadGuarniciones As Integer = clbGuarniciones.Items.Count
        Dim i As Integer = 0
        While i < cantidadGuarniciones - 1
            If clbGuarniciones.CheckedIndices(i) Then
                _codGuanicion = clbGuarniciones.Items(i)
                nuevoProducto.Guarniciones.Add(Producto.Cargar(_codGuanicion.Item(0)))
            End If
            i = i + 1
        End While

        ' Stock's , Precio y PVP
        nuevoProducto.Stock = tbStock.Text
        nuevoProducto.StockMinimo = tbStock.Text
        nuevoProducto.PrecioCoste = tbPrecio.Text
        nuevoProducto.PVP = tbPVP.Text

        'IVA
        _codIva = cbIVA.Items(cbIVA.SelectedIndex)
        nuevoProducto.IVA = TipoIVA.Cargar(_codIva.Item(0))

        'Activado?
        nuevoProducto.Activo = 1

        nuevoProducto.Insertar()
    End Sub

    Private Sub btBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btBorrar.Click

    End Sub

    Private Sub cbCategoria_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbCategoria.SelectedValueChanged
        _codCategoria = cbCategoria.Items(cbCategoria.SelectedIndex)
        ' Cargamos Subcategorias al cambiar de categoria
        If _codCategoria.Item(0) >= 0 Then
            cbSubcategoria.DataSource = SubCategoria.CargarDatos(Categoria.Cargar(_codCategoria.Item(0))).Tables("subcategorias")
            cbSubcategoria.DisplayMember = "nombre"
            cbSubcategoria.ValueMember = "codigo"
        Else
            MsgBox("No hay una categoria seleccionada")
        End If

        ' Ponemos visible las guarniciones si es un Plato si no lo es se vuelven invisibles
        If _codCategoria.Item(0) = 3 Then
            Me.Label9.Visible = True
            Me.clbGuarniciones.Visible = True
            Me.clbGuarniciones.Enabled = True
        Else
            Me.Label9.Visible = False
            Me.clbGuarniciones.Visible = False
            Me.clbGuarniciones.Enabled = False
        End If
    End Sub
#End Region

End Class
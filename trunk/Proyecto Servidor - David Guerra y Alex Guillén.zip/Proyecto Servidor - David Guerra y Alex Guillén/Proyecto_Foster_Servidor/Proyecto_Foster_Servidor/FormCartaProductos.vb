﻿Imports FostersClases

''' <summary>
''' 
''' </summary>
''' <author>David Guerra Abad, Alejandro Guillén Esteso</author>
Public Class FormCartaProductos

#Region "Variables"
    Dim _Opcion As String
    Dim _dsProductos As DataSet
    Dim _dvProductos As DataView
#End Region

#Region "Constructor"
    Public Sub New()
        InitializeComponent()
        _Opcion = "DEFAULT"
    End Sub

    Public Sub New(ByVal producto As String)
        InitializeComponent()
        _Opcion = producto
    End Sub
#End Region

#Region "Eventos"
    Private Sub FormCartaBebidas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "Carta " & _Opcion
        CargarDataGridView()
        dgvCarta.Columns(0).ReadOnly = True
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If _dsProductos.HasChanges Then
            MsgBox(Producto.Actualizar(_dsProductos))
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        _dsProductos.RejectChanges()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
#End Region

#Region "Metodos"
    Private Sub CargarDataGridView()
        If _Opcion = "BEBIDAS" Then
            _dsProductos = Producto.CargarDatos()
            _dvProductos = _dsProductos.Tables("productos").DefaultView
            _dvProductos.RowFilter = "CODIGO_CATEGORIA = 2"
            dgvCarta.DataSource = _dsProductos.Tables("productos")

        ElseIf _Opcion = "ENTRANTES" Then
            _dsProductos = Producto.CargarDatos()
            _dvProductos = _dsProductos.Tables("productos").DefaultView
            _dvProductos.RowFilter = "CODIGO_CATEGORIA = 3 AND CODIGO_SUBCATEGORIA = 1"
            dgvCarta.DataSource = _dsProductos.Tables("productos")

        ElseIf _Opcion = "INFANTILES" Then
            _dsProductos = Producto.CargarDatos()
            _dvProductos = _dsProductos.Tables("productos").DefaultView
            _dvProductos.RowFilter = "CODIGO_CATEGORIA = 3 AND CODIGO_SUBCATEGORIA = 9"
            dgvCarta.DataSource = _dsProductos.Tables("productos")

        ElseIf _Opcion = "HAMBURGUESAS" Then
            _dsProductos = Producto.CargarDatos()
            _dvProductos = _dsProductos.Tables("productos").DefaultView
            _dvProductos.RowFilter = "CODIGO_CATEGORIA = 3 AND CODIGO_SUBCATEGORIA = 8"
            dgvCarta.DataSource = _dsProductos.Tables("productos")

        ElseIf _Opcion = "COSTILLAS" Then
            _dsProductos = Producto.CargarDatos()
            _dvProductos = _dsProductos.Tables("productos").DefaultView
            _dvProductos.RowFilter = "CODIGO_CATEGORIA = 3 AND CODIGO_SUBCATEGORIA = 7"
            dgvCarta.DataSource = _dsProductos.Tables("productos")

        ElseIf _Opcion = "TEXMEX" Then
            _dsProductos = Producto.CargarDatos()
            _dvProductos = _dsProductos.Tables("productos").DefaultView
            _dvProductos.RowFilter = "CODIGO_CATEGORIA = 3 AND CODIGO_SUBCATEGORIA = 3"
            dgvCarta.DataSource = _dsProductos.Tables("productos")

        ElseIf _Opcion = "SANDWICH" Then
            _dsProductos = Producto.CargarDatos()
            _dvProductos = _dsProductos.Tables("productos").DefaultView
            _dvProductos.RowFilter = "CODIGO_CATEGORIA = 3 AND CODIGO_SUBCATEGORIA = 4"
            dgvCarta.DataSource = _dsProductos.Tables("productos")

        ElseIf _Opcion = "POLLO/PESCADO" Then
            _dsProductos = Producto.CargarDatos()
            _dvProductos = _dsProductos.Tables("productos").DefaultView
            _dvProductos.RowFilter = "CODIGO_CATEGORIA = 3 AND CODIGO_SUBCATEGORIA = 5"
            dgvCarta.DataSource = _dsProductos.Tables("productos")

        ElseIf _Opcion = "PARRILLA" Then
            _dsProductos = Producto.CargarDatos()
            _dvProductos = _dsProductos.Tables("productos").DefaultView
            _dvProductos.RowFilter = "CODIGO_CATEGORIA = 3 AND CODIGO_SUBCATEGORIA = 6"
            dgvCarta.DataSource = _dsProductos.Tables("productos")

        ElseIf _Opcion = "POSTRES" Then
            _dsProductos = Producto.CargarDatos()
            _dvProductos = _dsProductos.Tables("productos").DefaultView
            _dvProductos.RowFilter = "CODIGO_CATEGORIA = 3 AND CODIGO_SUBCATEGORIA = 10"
            dgvCarta.DataSource = _dsProductos.Tables("productos")

        ElseIf _Opcion = "ACOMPAÑAMIENTOS" Then
            _dsProductos = Producto.CargarDatos()
            _dvProductos = _dsProductos.Tables("productos").DefaultView
            _dvProductos.RowFilter = "CODIGO_CATEGORIA = 3 AND CODIGO_SUBCATEGORIA = 1"
            dgvCarta.DataSource = _dsProductos.Tables("productos")

        ElseIf _Opcion = "DEFAULT" Then
            _dsProductos = Producto.CargarDatos()
            dgvCarta.DataSource = _dsProductos.Tables("productos")
        End If
    End Sub
#End Region
End Class
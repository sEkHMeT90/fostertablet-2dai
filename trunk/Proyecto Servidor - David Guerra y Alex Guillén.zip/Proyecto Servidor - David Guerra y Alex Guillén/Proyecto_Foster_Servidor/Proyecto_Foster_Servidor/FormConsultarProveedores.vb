﻿Imports FostersClases
''' <summary>
''' Form que muestra todos los Proveedores
''' </summary>
''' <author>David Guerra Abad</author>
Public Class FormConsultarProveedores

#Region "Variables"
    Dim _dsProveedores As DataSet
#End Region

#Region "Eventos"

    Private Sub FormConsultarProveedores_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If _dsProveedores.HasChanges Then
            MsgBox(Proveedor.Actualizar(_dsProveedores))
        End If
    End Sub
    Private Sub FormConsultarProveedores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        _dsProveedores = Proveedor.CargarDatos()
        dgvProveedores.DataSource = _dsProveedores.Tables("proveedores")
    End Sub

    Private Sub dgvProveedores_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvProveedores.CellValueChanged
        If CType(sender, DataGridViewCell).ColumnIndex = 0 Then
            'CIF
            If Not ValidarNumeroEntero(CType(sender, DataGridViewCell).Value, 8, 8) Then
                dgvProveedores.CurrentCell = CType(sender, DataGridViewCell)
            End If
        End If
        If CType(sender, DataGridViewCell).ColumnIndex = 1 Then
            'Nombre
            If Not ValidarTexto(CType(sender, DataGridViewCell).Value, 1, 30) Then
                dgvProveedores.CurrentCell = CType(sender, DataGridViewCell)
            End If
        End If
        If CType(sender, DataGridViewCell).ColumnIndex = 2 Then
            'Direccion
            If Not ValidarTexto(CType(sender, DataGridViewCell).Value, 1, 200) Then
                dgvProveedores.CurrentCell = CType(sender, DataGridViewCell)
            End If
        End If
        If CType(sender, DataGridViewCell).ColumnIndex = 3 Then
            'Telefono
            If Not ValidarNumeroEntero(CType(sender, DataGridViewCell).Value, 9, 9) Then
                dgvProveedores.CurrentCell = CType(sender, DataGridViewCell)
            End If
        End If
        If CType(sender, DataGridViewCell).ColumnIndex = 4 Then
            'Activo
            If Not (CType(sender, DataGridViewCell).Value = 1 Or CType(sender, DataGridViewCell).Value = 0) Then
                dgvProveedores.CurrentCell = CType(sender, DataGridViewCell)
            End If
        End If

    End Sub
#End Region

End Class
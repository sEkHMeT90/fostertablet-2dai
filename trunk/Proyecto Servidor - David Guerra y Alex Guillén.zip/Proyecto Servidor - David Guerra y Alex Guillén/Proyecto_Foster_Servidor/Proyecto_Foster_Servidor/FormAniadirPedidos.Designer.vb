﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormAniadirPedidos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.cbProveedor = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbProducto = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.tbPrecio = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dgvPedido = New System.Windows.Forms.DataGridView()
        Me.CodProducto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Precio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.tbPrecioTotal = New System.Windows.Forms.TextBox()
        Me.btAniadir = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblFechaActual = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.btAniadirPedido = New System.Windows.Forms.Button()
        Me.btCancelarPedido = New System.Windows.Forms.Button()
        Me.tbCantida = New System.Windows.Forms.TextBox()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvPedido, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cbProveedor
        '
        Me.cbProveedor.FormattingEnabled = True
        Me.cbProveedor.Location = New System.Drawing.Point(98, 42)
        Me.cbProveedor.Name = "cbProveedor"
        Me.cbProveedor.Size = New System.Drawing.Size(192, 21)
        Me.cbProveedor.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(37, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Proveedor"
        '
        'cbProducto
        '
        Me.cbProducto.FormattingEnabled = True
        Me.cbProducto.Location = New System.Drawing.Point(98, 108)
        Me.cbProducto.Name = "cbProducto"
        Me.cbProducto.Size = New System.Drawing.Size(192, 21)
        Me.cbProducto.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(37, 111)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Producto"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(313, 111)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Cantidad"
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'tbPrecio
        '
        Me.tbPrecio.Location = New System.Drawing.Point(411, 149)
        Me.tbPrecio.Name = "tbPrecio"
        Me.tbPrecio.ReadOnly = True
        Me.tbPrecio.Size = New System.Drawing.Size(100, 20)
        Me.tbPrecio.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(357, 152)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Precio"
        '
        'dgvPedido
        '
        Me.dgvPedido.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvPedido.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CodProducto, Me.Precio, Me.Cantidad})
        Me.dgvPedido.Location = New System.Drawing.Point(12, 199)
        Me.dgvPedido.Name = "dgvPedido"
        Me.dgvPedido.Size = New System.Drawing.Size(350, 271)
        Me.dgvPedido.TabIndex = 12
        '
        'CodProducto
        '
        Me.CodProducto.HeaderText = "Código Producto"
        Me.CodProducto.Name = "CodProducto"
        '
        'Precio
        '
        Me.Precio.HeaderText = "Precio"
        Me.Precio.Name = "Precio"
        '
        'Cantidad
        '
        Me.Cantidad.HeaderText = "Cantidad"
        Me.Cantidad.Name = "Cantidad"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(55, 507)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(67, 13)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Precio Total:"
        '
        'tbPrecioTotal
        '
        Me.tbPrecioTotal.Location = New System.Drawing.Point(130, 504)
        Me.tbPrecioTotal.Name = "tbPrecioTotal"
        Me.tbPrecioTotal.Size = New System.Drawing.Size(141, 20)
        Me.tbPrecioTotal.TabIndex = 14
        '
        'btAniadir
        '
        Me.btAniadir.Location = New System.Drawing.Point(40, 152)
        Me.btAniadir.Name = "btAniadir"
        Me.btAniadir.Size = New System.Drawing.Size(120, 23)
        Me.btAniadir.TabIndex = 15
        Me.btAniadir.Text = "Añadir Linea Pedido"
        Me.btAniadir.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(333, 45)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 13)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Fecha Actual:"
        '
        'lblFechaActual
        '
        Me.lblFechaActual.AutoSize = True
        Me.lblFechaActual.Location = New System.Drawing.Point(442, 45)
        Me.lblFechaActual.Name = "lblFechaActual"
        Me.lblFechaActual.Size = New System.Drawing.Size(37, 13)
        Me.lblFechaActual.TabIndex = 18
        Me.lblFechaActual.Text = "Fecha"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'btAniadirPedido
        '
        Me.btAniadirPedido.Location = New System.Drawing.Point(431, 219)
        Me.btAniadirPedido.Name = "btAniadirPedido"
        Me.btAniadirPedido.Size = New System.Drawing.Size(75, 62)
        Me.btAniadirPedido.TabIndex = 19
        Me.btAniadirPedido.Text = "Añadir Pedido"
        Me.btAniadirPedido.UseVisualStyleBackColor = True
        '
        'btCancelarPedido
        '
        Me.btCancelarPedido.Location = New System.Drawing.Point(431, 334)
        Me.btCancelarPedido.Name = "btCancelarPedido"
        Me.btCancelarPedido.Size = New System.Drawing.Size(75, 62)
        Me.btCancelarPedido.TabIndex = 20
        Me.btCancelarPedido.Text = "Cancelar Pedido"
        Me.btCancelarPedido.UseVisualStyleBackColor = True
        '
        'tbCantida
        '
        Me.tbCantida.Location = New System.Drawing.Point(379, 108)
        Me.tbCantida.Name = "tbCantida"
        Me.tbCantida.Size = New System.Drawing.Size(100, 20)
        Me.tbCantida.TabIndex = 21
        Me.tbCantida.Text = "1"
        '
        'FormAniadirPedidos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(566, 562)
        Me.Controls.Add(Me.tbCantida)
        Me.Controls.Add(Me.btCancelarPedido)
        Me.Controls.Add(Me.btAniadirPedido)
        Me.Controls.Add(Me.lblFechaActual)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.btAniadir)
        Me.Controls.Add(Me.tbPrecioTotal)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.dgvPedido)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.tbPrecio)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cbProducto)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cbProveedor)
        Me.Name = "FormAniadirPedidos"
        Me.Text = "Pedidos"
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvPedido, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cbProveedor As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cbProducto As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents tbPrecio As System.Windows.Forms.TextBox
    Friend WithEvents lblFechaActual As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btAniadir As System.Windows.Forms.Button
    Friend WithEvents tbPrecioTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents dgvPedido As System.Windows.Forms.DataGridView
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents btCancelarPedido As System.Windows.Forms.Button
    Friend WithEvents btAniadirPedido As System.Windows.Forms.Button
    Friend WithEvents CodProducto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Precio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Cantidad As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents tbCantida As System.Windows.Forms.TextBox
End Class

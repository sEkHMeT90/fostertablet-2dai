﻿Imports FostersClases
''' <summary>
''' Form que muestra las mesas que tenemos en el local
''' </summary>
''' <author>David Guerra Abad</author>
Public Class FormVerMesas

#Region "Variables"
    Dim _dsMesas As DataSet

    Private dataSetMesas As DataSet
#End Region

#Region "Eventos"
    Private Sub VerMesas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        _dsMesas = Mesa.CargarDatos()
        dgvMesas.DataSource = _dsMesas.Tables("MESAS")
    End Sub

    Private Sub dgvMesas_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvMesas.CellContentClick
        FormComandasMesa.codigo = dgvMesas.CurrentRow.Cells(1).Value
        FormComandasMesa.ShowDialog()
    End Sub

    Private Sub btAgregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btAgregar.Click
        If Mesa.Insertar() Then
            _dsMesas = Mesa.CargarDatos()
            dgvMesas.DataSource = _dsMesas.Tables("MESAS")
        End If
    End Sub

    Private Sub btSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSalir.Click
        Me.Close()
    End Sub
#End Region
   
End Class
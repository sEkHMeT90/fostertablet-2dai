﻿Imports FostersClases
''' <summary>
''' Muestra las comandas de una mesa seleccionada previamente en la tabla del form anterior
''' </summary>
''' <author>David Guerra Abad</author>
Public Class FormComandasMesa
#Region "Variables"
    Dim _codigo As String
    Dim _dsComandas As DataSet
    Dim _dvComandas As DataView
#End Region

#Region "Propiedades"
    Public Property codigo As String
        Set(ByVal value As String)
            _codigo = value
        End Set
        Get
            Return _codigo
        End Get
    End Property
#End Region

#Region "Eventos"

    Private Sub FormComandasMesa_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If _dsComandas.HasChanges Then
            MsgBox(LineaComanda.Actualizar(_dsComandas))
        End If
    End Sub
    Private Sub FormComandasMesa_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim comanda As Comanda = New Comanda()
        comanda.Codigo = _codigo
        _dsComandas = LineaComanda.CargarDatos(comanda)
        dgvComandas.DataSource = _dsComandas.Tables("lineas_comanda")
    End Sub
#End Region
    
End Class
﻿Imports FostersClases
''' <summary>
''' Form para hacer pedidos a un proveedor en concreto
''' </summary>
''' <author>David Guerra Abad</author>
Public Class FormAniadirPedidos

#Region "Variables"
    Dim precioTotal As Double
    Dim listaProveedores As DataSet
    Dim listaProductos As DataSet
    Dim listaPrecios As ComboBox
    Dim listaLineas As List(Of LineaPedido)
    Dim cantidadLineas As Integer
#End Region

#Region "Funciones"
    Sub rellenarProveedores()
        listaProveedores = Proveedor.CargarDatos()
        cbProveedor.DataSource = listaProveedores.Tables("proveedores")
        cbProveedor.DisplayMember = "nombre"
        cbProveedor.ValueMember = "CIF"
    End Sub

    Sub rellenarProductos()
        listaProductos = Producto.CargarDatos()
        cbProducto.DataSource = listaProductos.Tables("productos")
        cbProducto.DisplayMember = "NOMBRE"
        cbProducto.ValueMember = "CODIGO"
        listaPrecios.DataSource = listaProductos.Tables("productos")
        listaPrecios.ValueMember = "PRECIO"
    End Sub
#End Region

#Region "Eventos"
    Private Sub FormAniadirPedidos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lblFechaActual.Text = CStr(Date.Now)
        precioTotal = 0
        tbPrecio.Text = "0"
        tbPrecioTotal.Text = "0"
        listaPrecios = New ComboBox
        listaLineas = New List(Of LineaPedido)
        cantidadLineas = 0
        rellenarProductos()
        rellenarProveedores()
    End Sub

    Private Sub TextBox2_Validating(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs)
        Try
            If CInt(tbCantida.Text) Then
                e.Cancel = False
                ErrorProvider1.Clear()
            End If
        Catch ex As Exception
            ErrorProvider1.SetError(sender, "Error: Solo se permiten números")
            e.Cancel = True
        End Try

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        lblFechaActual.Text = CStr(Date.Now)
    End Sub

    Private Sub cbProducto_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbProducto.SelectedIndexChanged
        Dim precio As String = listaProductos.Tables("productos").Rows(cbProducto.SelectedIndex()).Item(3)
        precio = precio.Replace(".", ",")
        tbPrecio.Text = CDbl(tbCantida.Text) * precio
    End Sub

    Private Sub btAniadir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btAniadir.Click
        cantidadLineas += 1
        cbProveedor.Enabled = False
        precioTotal = precioTotal + tbPrecio.Text
        tbPrecioTotal.Text = precioTotal
        Dim precio As String = listaProductos.Tables("productos").Rows(cbProducto.SelectedIndex()).Item(3)
        precio = precio.Replace(".", ",")
        Dim lineaNueva(3) As String
        lineaNueva(0) = cbProducto.SelectedValue
        lineaNueva(1) = precio
        lineaNueva(2) = tbCantida.Text
        dgvPedido.Rows.Add(lineaNueva)
        Dim producto As Producto
        producto = New Producto()
        producto.Cargar(listaProductos.Tables("productos").Rows(cbProducto.SelectedIndex()).Item(0))
        Dim linea As LineaPedido
        linea = New LineaPedido(cantidadLineas, producto, tbCantida.Text)
        listaLineas.Add(linea)
    End Sub

    Private Sub btAniadirPedido_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btAniadirPedido.Click
        Dim pedido As Pedido

        Dim cif As String = listaProveedores.Tables("proveedores").Rows(cbProveedor.SelectedIndex()).Item(0)
        Dim nombre As String = listaProveedores.Tables("proveedores").Rows(cbProveedor.SelectedIndex()).Item(1)
        Dim direccion As String = listaProveedores.Tables("proveedores").Rows(cbProveedor.SelectedIndex()).Item(2)
        Dim telefono As String = listaProveedores.Tables("proveedores").Rows(cbProveedor.SelectedIndex()).Item(3)

        Dim proveedor As Proveedor = New Proveedor(cif, nombre, direccion, telefono, True)

        pedido = New Pedido(1, Date.Now, proveedor, precioTotal, False, listaLineas)
        If (pedido.Insertar()) Then
            MessageBox.Show("Se ha insertado el pedido")
        Else
            MessageBox.Show("No se ha insertado el pedido")
        End If


    End Sub

    Private Sub btCancelarPedido_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btCancelarPedido.Click
        Me.Close()
    End Sub

    Private Sub tbCantidad_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbCantida.TextChanged
        Try
            Dim precio As Double = listaProductos.Tables("productos").Rows(cbProducto.SelectedIndex()).Item(3)
            tbPrecio.Text = CDbl(tbCantida.Text) * precio
        Catch ex As Exception
            MessageBox.Show("Error: Solo se permiten números en el campo cantidad")
            tbCantida.Focus()
        End Try

    End Sub
#End Region

End Class
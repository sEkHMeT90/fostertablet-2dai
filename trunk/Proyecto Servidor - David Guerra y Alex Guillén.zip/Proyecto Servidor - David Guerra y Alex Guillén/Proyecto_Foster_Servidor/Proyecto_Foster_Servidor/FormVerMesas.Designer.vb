﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormVerMesas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvMesas = New System.Windows.Forms.DataGridView()
        Me.btAgregar = New System.Windows.Forms.Button()
        Me.btSalir = New System.Windows.Forms.Button()
        CType(Me.dgvMesas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvMesas
        '
        Me.dgvMesas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvMesas.Location = New System.Drawing.Point(12, 12)
        Me.dgvMesas.Name = "dgvMesas"
        Me.dgvMesas.Size = New System.Drawing.Size(194, 292)
        Me.dgvMesas.TabIndex = 0
        '
        'btAgregar
        '
        Me.btAgregar.Location = New System.Drawing.Point(252, 55)
        Me.btAgregar.Name = "btAgregar"
        Me.btAgregar.Size = New System.Drawing.Size(75, 55)
        Me.btAgregar.TabIndex = 1
        Me.btAgregar.Text = "Agregar Mesa"
        Me.btAgregar.UseVisualStyleBackColor = True
        '
        'btSalir
        '
        Me.btSalir.Location = New System.Drawing.Point(252, 173)
        Me.btSalir.Name = "btSalir"
        Me.btSalir.Size = New System.Drawing.Size(75, 55)
        Me.btSalir.TabIndex = 2
        Me.btSalir.Text = "Salir"
        Me.btSalir.UseVisualStyleBackColor = True
        '
        'FormVerMesas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(355, 333)
        Me.Controls.Add(Me.btSalir)
        Me.Controls.Add(Me.btAgregar)
        Me.Controls.Add(Me.dgvMesas)
        Me.Name = "FormVerMesas"
        Me.Text = "Mesas"
        CType(Me.dgvMesas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents dgvMesas As System.Windows.Forms.DataGridView
    Friend WithEvents btAgregar As System.Windows.Forms.Button
    Friend WithEvents btSalir As System.Windows.Forms.Button
End Class

﻿''' <summary>
''' TODO: Debería restaurar la copia de seguridad guardada
''' </summary>
''' <author>David Guerra Abad</author>
Public Class FormRestaurarCopiaSeguridad

#Region "Eventos"
    Private Sub RestaurarCopiaSeguridad_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO
    End Sub

    Private Sub btBuscarCopia_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btBuscarCopia.Click
        OpenFileDialog1.ShowDialog()
        TextBox1.Text = OpenFileDialog1.FileName
    End Sub

    Private Sub btRestaurarCopia_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btRestaurarCopia.Click
        'TODO
    End Sub
#End Region

End Class
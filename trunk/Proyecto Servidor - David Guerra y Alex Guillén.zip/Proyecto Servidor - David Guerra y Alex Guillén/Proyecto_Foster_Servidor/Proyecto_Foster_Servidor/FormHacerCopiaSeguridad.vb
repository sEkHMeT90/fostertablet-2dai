﻿''' <summary>
''' TO DO: Debería realizar las copias de seguridad de la base de datos
''' </summary>
''' <author>David Guerra Abad</author>
Public Class FormHacerCopiaSeguridad
#Region "Eventos"
    Private Sub HacerCopiaSeguridad_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Width = 683
        Me.Height = 134
    End Sub

    Private Sub btCrearCopia_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btCrearCopia.Click
        'TODO
    End Sub
#End Region
    
End Class
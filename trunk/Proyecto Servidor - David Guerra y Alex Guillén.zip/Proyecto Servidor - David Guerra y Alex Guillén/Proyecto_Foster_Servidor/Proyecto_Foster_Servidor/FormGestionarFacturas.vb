﻿Imports FostersClases
''' <summary>
''' Form que muestra las lineas de Factura una factura
''' </summary>
''' <author>David Guerra Abad</author>
Public Class FormGestionarFacturas

#Region "Variables"
    Dim _codigo As String
    Dim _dsFacturas As DataSet
    Dim _dvFacturas As DataView
#End Region

#Region "Propiedades"
    Public Property codigo As String
        Set(ByVal value As String)
            _codigo = value
        End Set
        Get
            Return _codigo
        End Get
    End Property
#End Region

#Region "Eventos"

    Private Sub FormGestionarFacturas_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If _dsFacturas.HasChanges Then
            MsgBox(LineaTicket.Actualizar(_dsFacturas))
        End If
    End Sub
    Private Sub FormGestionarFacturas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim ticket As Ticket = New Ticket()
        ticket.Codigo = _codigo
        _dsFacturas = LineaTicket.CargarDatos(ticket)
        dgvLinFactura.DataSource = _dsFacturas.Tables("lineas_ticket")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'TODO
    End Sub
#End Region

End Class
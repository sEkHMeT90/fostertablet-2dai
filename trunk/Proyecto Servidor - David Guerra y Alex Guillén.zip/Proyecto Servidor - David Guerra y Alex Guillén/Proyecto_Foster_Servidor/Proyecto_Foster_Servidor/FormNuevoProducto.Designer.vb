﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormNuevoProducto
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbCodigo = New System.Windows.Forms.TextBox()
        Me.tbNombre = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbDescripcion = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbPrecio = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tbPVP = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.tbCalorias = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.tbStockMin = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.tbStock = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.clbGuarniciones = New System.Windows.Forms.CheckedListBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cbSubcategoria = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cbIVA = New System.Windows.Forms.ComboBox()
        Me.btAniadir = New System.Windows.Forms.Button()
        Me.btBorrar = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.cbCategoria = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(30, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Código:"
        '
        'tbCodigo
        '
        Me.tbCodigo.Enabled = False
        Me.tbCodigo.Location = New System.Drawing.Point(107, 21)
        Me.tbCodigo.Name = "tbCodigo"
        Me.tbCodigo.Size = New System.Drawing.Size(100, 20)
        Me.tbCodigo.TabIndex = 1
        '
        'tbNombre
        '
        Me.tbNombre.Location = New System.Drawing.Point(107, 47)
        Me.tbNombre.Name = "tbNombre"
        Me.tbNombre.Size = New System.Drawing.Size(187, 20)
        Me.tbNombre.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(30, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Nombre:"
        '
        'tbDescripcion
        '
        Me.tbDescripcion.Location = New System.Drawing.Point(107, 73)
        Me.tbDescripcion.Multiline = True
        Me.tbDescripcion.Name = "tbDescripcion"
        Me.tbDescripcion.Size = New System.Drawing.Size(187, 97)
        Me.tbDescripcion.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 76)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Descripción:"
        '
        'tbPrecio
        '
        Me.tbPrecio.Location = New System.Drawing.Point(435, 129)
        Me.tbPrecio.Name = "tbPrecio"
        Me.tbPrecio.Size = New System.Drawing.Size(100, 20)
        Me.tbPrecio.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(353, 132)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Precio:"
        '
        'tbPVP
        '
        Me.tbPVP.Location = New System.Drawing.Point(435, 155)
        Me.tbPVP.Name = "tbPVP"
        Me.tbPVP.Size = New System.Drawing.Size(100, 20)
        Me.tbPVP.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(353, 158)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(31, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "PVP:"
        '
        'tbCalorias
        '
        Me.tbCalorias.Location = New System.Drawing.Point(107, 181)
        Me.tbCalorias.Name = "tbCalorias"
        Me.tbCalorias.Size = New System.Drawing.Size(100, 20)
        Me.tbCalorias.TabIndex = 11
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(30, 184)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Calorías:"
        '
        'tbStockMin
        '
        Me.tbStockMin.Location = New System.Drawing.Point(435, 76)
        Me.tbStockMin.Name = "tbStockMin"
        Me.tbStockMin.Size = New System.Drawing.Size(100, 20)
        Me.tbStockMin.TabIndex = 15
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(353, 79)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Stock Mínimo:"
        '
        'tbStock
        '
        Me.tbStock.Location = New System.Drawing.Point(435, 47)
        Me.tbStock.Name = "tbStock"
        Me.tbStock.Size = New System.Drawing.Size(100, 20)
        Me.tbStock.TabIndex = 13
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(353, 50)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(38, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Stock:"
        '
        'clbGuarniciones
        '
        Me.clbGuarniciones.Enabled = False
        Me.clbGuarniciones.FormattingEnabled = True
        Me.clbGuarniciones.Location = New System.Drawing.Point(109, 261)
        Me.clbGuarniciones.Name = "clbGuarniciones"
        Me.clbGuarniciones.Size = New System.Drawing.Size(120, 94)
        Me.clbGuarniciones.TabIndex = 16
        Me.clbGuarniciones.Visible = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(30, 261)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(72, 13)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "Guarniciones:"
        Me.Label9.Visible = False
        '
        'cbSubcategoria
        '
        Me.cbSubcategoria.FormattingEnabled = True
        Me.cbSubcategoria.Location = New System.Drawing.Point(108, 234)
        Me.cbSubcategoria.Name = "cbSubcategoria"
        Me.cbSubcategoria.Size = New System.Drawing.Size(121, 21)
        Me.cbSubcategoria.TabIndex = 18
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(30, 237)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(73, 13)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Subcategoria:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(353, 105)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(51, 13)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "Tipo IVA:"
        '
        'cbIVA
        '
        Me.cbIVA.FormattingEnabled = True
        Me.cbIVA.Location = New System.Drawing.Point(435, 102)
        Me.cbIVA.Name = "cbIVA"
        Me.cbIVA.Size = New System.Drawing.Size(121, 21)
        Me.cbIVA.TabIndex = 20
        '
        'btAniadir
        '
        Me.btAniadir.Location = New System.Drawing.Point(404, 220)
        Me.btAniadir.Name = "btAniadir"
        Me.btAniadir.Size = New System.Drawing.Size(99, 46)
        Me.btAniadir.TabIndex = 22
        Me.btAniadir.Text = "Añadir Producto"
        Me.btAniadir.UseVisualStyleBackColor = True
        '
        'btBorrar
        '
        Me.btBorrar.Location = New System.Drawing.Point(404, 294)
        Me.btBorrar.Name = "btBorrar"
        Me.btBorrar.Size = New System.Drawing.Size(99, 46)
        Me.btBorrar.TabIndex = 23
        Me.btBorrar.Text = "Borrar Campos"
        Me.btBorrar.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(30, 210)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(55, 13)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "Categoria:"
        '
        'cbCategoria
        '
        Me.cbCategoria.FormattingEnabled = True
        Me.cbCategoria.Location = New System.Drawing.Point(107, 207)
        Me.cbCategoria.Name = "cbCategoria"
        Me.cbCategoria.Size = New System.Drawing.Size(121, 21)
        Me.cbCategoria.TabIndex = 25
        '
        'FormNuevoProducto
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(598, 365)
        Me.Controls.Add(Me.cbCategoria)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.btBorrar)
        Me.Controls.Add(Me.btAniadir)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.cbIVA)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.cbSubcategoria)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.clbGuarniciones)
        Me.Controls.Add(Me.tbStockMin)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.tbStock)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.tbCalorias)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.tbPVP)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.tbPrecio)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.tbDescripcion)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tbNombre)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.tbCodigo)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FormNuevoProducto"
        Me.Text = "FormNuevoProducto"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tbCodigo As System.Windows.Forms.TextBox
    Friend WithEvents tbNombre As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tbDescripcion As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tbPrecio As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents tbPVP As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents tbCalorias As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents tbStockMin As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents tbStock As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents clbGuarniciones As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents cbSubcategoria As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cbIVA As System.Windows.Forms.ComboBox
    Friend WithEvents btAniadir As System.Windows.Forms.Button
    Friend WithEvents btBorrar As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents cbCategoria As System.Windows.Forms.ComboBox
End Class

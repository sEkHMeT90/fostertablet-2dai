﻿Imports FostersClases
''' <summary>
''' Muestra los pedidos de la base de datos
''' </summary>
''' <author>David Guerra Abad</author>
Public Class FormConsultarPedidos

#Region "Variables"
    Dim _dsPedidos As DataSet
#End Region

#Region "Eventos"

    Private Sub FormConsultarPedidos_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If _dsPedidos.HasChanges Then
            MsgBox(Pedido.Actualizar(_dsPedidos))
        End If
    End Sub
    Private Sub FormConsultarPedidos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        _dsPedidos = Pedido.CargarDatos()
        dgvPedidos.DataSource = _dsPedidos.Tables("pedidos")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        FormAniadirPedidos.ShowDialog()
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvPedidos.CellContentClick
        FormGestionarPedidos.codigo = dgvPedidos.CurrentRow.Cells(0).Value
        FormGestionarPedidos.ShowDialog()
    End Sub
#End Region

End Class
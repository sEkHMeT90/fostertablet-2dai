﻿''' <summary>
''' Menú de inicio de la aplicación. Se accederá a todas las opciones desde la Barra de Herramientas
''' </summary>
''' <author>David Guerra Abad, Alejandro Guillén Esteso</author>
Public Class FormPrincipal

#Region "Eventos"
    Private Sub FormPrincipal_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    End Sub

    Private Sub tsmiCopiaSeguridad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmiCopiaSeguridad.Click
        FormHacerCopiaSeguridad.ShowDialog()
    End Sub

    Private Sub tsmiRestaurarCopiaSeguridad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmiRestaurarCopiaSeguridad.Click
        FormRestaurarCopiaSeguridad.ShowDialog()
    End Sub

    Private Sub tsmiSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmiSalir.Click
        Me.Close()
    End Sub

    Private Sub tsmiConsultarFecturas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmiConsultarFecturas.Click
        FormConsultarFacturas.ShowDialog()
    End Sub

    Private Sub tsmiConsultarPedidos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmiConsultarPedidos.Click
        FormConsultarPedidos.ShowDialog()
    End Sub

    Private Sub tsmiAñadirPedidos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmiAñadirPedidos.Click
        FormAniadirPedidos.ShowDialog()
    End Sub

    Private Sub VerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VerToolStripMenuItem.Click
        FormVerMesas.ShowDialog()
    End Sub

    Private Sub BebidasToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BebidasToolStripMenuItem.Click
        Dim _bebidas As New FormCartaProductos("BEBIDAS")
        _bebidas.ShowDialog()
    End Sub

    Private Sub EntrantesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EntrantesToolStripMenuItem.Click
        Dim _entrantes As New FormCartaProductos("ENTRANTES")
        _entrantes.ShowDialog()
    End Sub

    Private Sub InfantilesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InfantilesToolStripMenuItem.Click
        Dim _infantiles As New FormCartaProductos("INFANTILES")
        _infantiles.ShowDialog()
    End Sub

    Private Sub HamburguesasToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HamburguesasToolStripMenuItem.Click
        Dim _hamburguesas As New FormCartaProductos("HAMBURGUESAS")
        _hamburguesas.ShowDialog()
    End Sub

    Private Sub CostillasToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CostillasToolStripMenuItem.Click
        Dim _costillas As New FormCartaProductos("COSTILLAS")
        _costillas.ShowDialog()
    End Sub

    Private Sub TexMexToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TexMexToolStripMenuItem.Click
        Dim _texmex As New FormCartaProductos("TEXMEX")
        _texmex.ShowDialog()
    End Sub

    Private Sub SandwichToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SandwichToolStripMenuItem.Click
        Dim _sandwich As New FormCartaProductos("SANDWICH")
        _sandwich.ShowDialog()
    End Sub

    Private Sub PollopescadoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PollopescadoToolStripMenuItem.Click
        Dim _pollopescado As New FormCartaProductos("POLLO/PESCADO")
        _pollopescado.ShowDialog()
    End Sub

    Private Sub ParillaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ParillaToolStripMenuItem.Click
        Dim _parilla As New FormCartaProductos("PARRILLA")
        _parilla.ShowDialog()
    End Sub

    Private Sub PostresToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PostresToolStripMenuItem.Click
        Dim _postres As New FormCartaProductos("POSTRES")
        _postres.ShowDialog()
    End Sub

    Private Sub AcompañamientoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AcompañamientoToolStripMenuItem.Click
        Dim _acompa As New FormCartaProductos("ACOMPAÑAMIENTOS")
        _acompa.ShowDialog()
    End Sub

    Private Sub ConsultarToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConsultarToolStripMenuItem.Click
        FormConsultarProveedores.ShowDialog()
    End Sub

    Private Sub AgregarNuevoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AgregarNuevoToolStripMenuItem.Click
        FormNuevoProducto.ShowDialog()
    End Sub
#End Region

End Class
